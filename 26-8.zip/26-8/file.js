alert("external js is loading ")

